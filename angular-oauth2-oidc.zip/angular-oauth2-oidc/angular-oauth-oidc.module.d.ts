import { ModuleWithProviders } from '@angular/core';
import { OAuthModuleConfig } from './oauth-module.config';
import { NullValidationHandler } from './token-validation/null-validation-handler';
export declare class OAuthModule {
    static forRoot(config?: OAuthModuleConfig, validationHandlerClass?: typeof NullValidationHandler): ModuleWithProviders<OAuthModule>;
}
