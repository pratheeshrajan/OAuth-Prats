import * as i0 from '@angular/core';
import * as i1 from './angular-oauth-oidc.module';
export declare const OAuthModuleNgFactory: i0.NgModuleFactory<i1.OAuthModule>;
