import { __awaiter } from "tslib";
import { base64UrlEncode } from '../base64-helper';
/**
 * Interface for Handlers that are hooked in to
 * validate tokens.
 */
export class ValidationHandler {
}
/**
 * This abstract implementation of ValidationHandler already implements
 * the method validateAtHash. However, to make use of it,
 * you have to override the method calcHash.
 */
export class AbstractValidationHandler {
    /**
     * Validates the at_hash in an id_token against the received access_token.
     */
    validateAtHash(params) {
        return __awaiter(this, void 0, void 0, function* () {
            let hashAlg = this.inferHashAlgorithm(params.idTokenHeader);
            let tokenHash = yield this.calcHash(params.accessToken, hashAlg); // sha256(accessToken, { asString: true });
            let leftMostHalf = tokenHash.substr(0, tokenHash.length / 2);
            let atHash = base64UrlEncode(leftMostHalf);
            let claimsAtHash = params.idTokenClaims['at_hash'].replace(/=/g, '');
            if (atHash !== claimsAtHash) {
                console.error('exptected at_hash: ' + atHash);
                console.error('actual at_hash: ' + claimsAtHash);
            }
            return atHash === claimsAtHash;
        });
    }
    /**
     * Infers the name of the hash algorithm to use
     * from the alg field of an id_token.
     *
     * @param jwtHeader the id_token's parsed header
     */
    inferHashAlgorithm(jwtHeader) {
        let alg = jwtHeader['alg'];
        if (!alg.match(/^.S[0-9]{3}$/)) {
            throw new Error('Algorithm not supported: ' + alg);
        }
        return 'sha-' + alg.substr(2);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGlvbi1oYW5kbGVyLmpzIiwic291cmNlUm9vdCI6Im5nOi8vYW5ndWxhci1vYXV0aDItb2lkYy8iLCJzb3VyY2VzIjpbInRva2VuLXZhbGlkYXRpb24vdmFsaWRhdGlvbi1oYW5kbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFXbkQ7OztHQUdHO0FBQ0gsTUFBTSxPQUFnQixpQkFBaUI7Q0FZdEM7QUFFRDs7OztHQUlHO0FBQ0gsTUFBTSxPQUFnQix5QkFBeUI7SUFNN0M7O09BRUc7SUFDRyxjQUFjLENBQUMsTUFBd0I7O1lBQzNDLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFNUQsSUFBSSxTQUFTLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQywyQ0FBMkM7WUFFN0csSUFBSSxZQUFZLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztZQUU3RCxJQUFJLE1BQU0sR0FBRyxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFM0MsSUFBSSxZQUFZLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBRXJFLElBQUksTUFBTSxLQUFLLFlBQVksRUFBRTtnQkFDM0IsT0FBTyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsR0FBRyxNQUFNLENBQUMsQ0FBQztnQkFDOUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsR0FBRyxZQUFZLENBQUMsQ0FBQzthQUNsRDtZQUVELE9BQU8sTUFBTSxLQUFLLFlBQVksQ0FBQztRQUNqQyxDQUFDO0tBQUE7SUFFRDs7Ozs7T0FLRztJQUNPLGtCQUFrQixDQUFDLFNBQWlCO1FBQzVDLElBQUksR0FBRyxHQUFXLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVuQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUM5QixNQUFNLElBQUksS0FBSyxDQUFDLDJCQUEyQixHQUFHLEdBQUcsQ0FBQyxDQUFDO1NBQ3BEO1FBRUQsT0FBTyxNQUFNLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNoQyxDQUFDO0NBVUYiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBiYXNlNjRVcmxFbmNvZGUgfSBmcm9tICcuLi9iYXNlNjQtaGVscGVyJztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVmFsaWRhdGlvblBhcmFtcyB7XHJcbiAgaWRUb2tlbjogc3RyaW5nO1xyXG4gIGFjY2Vzc1Rva2VuOiBzdHJpbmc7XHJcbiAgaWRUb2tlbkhlYWRlcjogb2JqZWN0O1xyXG4gIGlkVG9rZW5DbGFpbXM6IG9iamVjdDtcclxuICBqd2tzOiBvYmplY3Q7XHJcbiAgbG9hZEtleXM6ICgpID0+IFByb21pc2U8b2JqZWN0PjtcclxufVxyXG5cclxuLyoqXHJcbiAqIEludGVyZmFjZSBmb3IgSGFuZGxlcnMgdGhhdCBhcmUgaG9va2VkIGluIHRvXHJcbiAqIHZhbGlkYXRlIHRva2Vucy5cclxuICovXHJcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBWYWxpZGF0aW9uSGFuZGxlciB7XHJcbiAgLyoqXHJcbiAgICogVmFsaWRhdGVzIHRoZSBzaWduYXR1cmUgb2YgYW4gaWRfdG9rZW4uXHJcbiAgICovXHJcbiAgcHVibGljIGFic3RyYWN0IHZhbGlkYXRlU2lnbmF0dXJlKFxyXG4gICAgdmFsaWRhdGlvblBhcmFtczogVmFsaWRhdGlvblBhcmFtc1xyXG4gICk6IFByb21pc2U8YW55PjtcclxuXHJcbiAgLyoqXHJcbiAgICogVmFsaWRhdGVzIHRoZSBhdF9oYXNoIGluIGFuIGlkX3Rva2VuIGFnYWluc3QgdGhlIHJlY2VpdmVkIGFjY2Vzc190b2tlbi5cclxuICAgKi9cclxuICBwdWJsaWMgYWJzdHJhY3QgdmFsaWRhdGVBdEhhc2godmFsaWRhdGlvblBhcmFtczogVmFsaWRhdGlvblBhcmFtcyk6IFByb21pc2U8Ym9vbGVhbj47XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBUaGlzIGFic3RyYWN0IGltcGxlbWVudGF0aW9uIG9mIFZhbGlkYXRpb25IYW5kbGVyIGFscmVhZHkgaW1wbGVtZW50c1xyXG4gKiB0aGUgbWV0aG9kIHZhbGlkYXRlQXRIYXNoLiBIb3dldmVyLCB0byBtYWtlIHVzZSBvZiBpdCxcclxuICogeW91IGhhdmUgdG8gb3ZlcnJpZGUgdGhlIG1ldGhvZCBjYWxjSGFzaC5cclxuICovXHJcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBBYnN0cmFjdFZhbGlkYXRpb25IYW5kbGVyIGltcGxlbWVudHMgVmFsaWRhdGlvbkhhbmRsZXIge1xyXG4gIC8qKlxyXG4gICAqIFZhbGlkYXRlcyB0aGUgc2lnbmF0dXJlIG9mIGFuIGlkX3Rva2VuLlxyXG4gICAqL1xyXG4gIGFic3RyYWN0IHZhbGlkYXRlU2lnbmF0dXJlKHZhbGlkYXRpb25QYXJhbXM6IFZhbGlkYXRpb25QYXJhbXMpOiBQcm9taXNlPGFueT47XHJcblxyXG4gIC8qKlxyXG4gICAqIFZhbGlkYXRlcyB0aGUgYXRfaGFzaCBpbiBhbiBpZF90b2tlbiBhZ2FpbnN0IHRoZSByZWNlaXZlZCBhY2Nlc3NfdG9rZW4uXHJcbiAgICovXHJcbiAgYXN5bmMgdmFsaWRhdGVBdEhhc2gocGFyYW1zOiBWYWxpZGF0aW9uUGFyYW1zKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgICBsZXQgaGFzaEFsZyA9IHRoaXMuaW5mZXJIYXNoQWxnb3JpdGhtKHBhcmFtcy5pZFRva2VuSGVhZGVyKTtcclxuXHJcbiAgICBsZXQgdG9rZW5IYXNoID0gYXdhaXQgdGhpcy5jYWxjSGFzaChwYXJhbXMuYWNjZXNzVG9rZW4sIGhhc2hBbGcpOyAvLyBzaGEyNTYoYWNjZXNzVG9rZW4sIHsgYXNTdHJpbmc6IHRydWUgfSk7XHJcblxyXG4gICAgbGV0IGxlZnRNb3N0SGFsZiA9IHRva2VuSGFzaC5zdWJzdHIoMCwgdG9rZW5IYXNoLmxlbmd0aCAvIDIpO1xyXG5cclxuICAgIGxldCBhdEhhc2ggPSBiYXNlNjRVcmxFbmNvZGUobGVmdE1vc3RIYWxmKTtcclxuXHJcbiAgICBsZXQgY2xhaW1zQXRIYXNoID0gcGFyYW1zLmlkVG9rZW5DbGFpbXNbJ2F0X2hhc2gnXS5yZXBsYWNlKC89L2csICcnKTtcclxuXHJcbiAgICBpZiAoYXRIYXNoICE9PSBjbGFpbXNBdEhhc2gpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignZXhwdGVjdGVkIGF0X2hhc2g6ICcgKyBhdEhhc2gpO1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdhY3R1YWwgYXRfaGFzaDogJyArIGNsYWltc0F0SGFzaCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGF0SGFzaCA9PT0gY2xhaW1zQXRIYXNoO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogSW5mZXJzIHRoZSBuYW1lIG9mIHRoZSBoYXNoIGFsZ29yaXRobSB0byB1c2VcclxuICAgKiBmcm9tIHRoZSBhbGcgZmllbGQgb2YgYW4gaWRfdG9rZW4uXHJcbiAgICpcclxuICAgKiBAcGFyYW0gand0SGVhZGVyIHRoZSBpZF90b2tlbidzIHBhcnNlZCBoZWFkZXJcclxuICAgKi9cclxuICBwcm90ZWN0ZWQgaW5mZXJIYXNoQWxnb3JpdGhtKGp3dEhlYWRlcjogb2JqZWN0KTogc3RyaW5nIHtcclxuICAgIGxldCBhbGc6IHN0cmluZyA9IGp3dEhlYWRlclsnYWxnJ107XHJcblxyXG4gICAgaWYgKCFhbGcubWF0Y2goL14uU1swLTldezN9JC8pKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcignQWxnb3JpdGhtIG5vdCBzdXBwb3J0ZWQ6ICcgKyBhbGcpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAnc2hhLScgKyBhbGcuc3Vic3RyKDIpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ2FsY3VsYXRlcyB0aGUgaGFzaCBmb3IgdGhlIHBhc3NlZCB2YWx1ZSBieSB1c2luZ1xyXG4gICAqIHRoZSBwYXNzZWQgaGFzaCBhbGdvcml0aG0uXHJcbiAgICpcclxuICAgKiBAcGFyYW0gdmFsdWVUb0hhc2hcclxuICAgKiBAcGFyYW0gYWxnb3JpdGhtXHJcbiAgICovXHJcbiAgcHJvdGVjdGVkIGFic3RyYWN0IGNhbGNIYXNoKHZhbHVlVG9IYXNoOiBzdHJpbmcsIGFsZ29yaXRobTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+O1xyXG59XHJcbiJdfQ==