import { MemoryStorage } from './types';
export declare function createDefaultLogger(): Console;
export declare function createDefaultStorage(): Storage | MemoryStorage;
