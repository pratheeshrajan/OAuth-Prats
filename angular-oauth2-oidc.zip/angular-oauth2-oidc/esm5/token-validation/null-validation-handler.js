/**
 * A validation handler that isn't validating nothing.
 * Can be used to skip validation (at your own risk).
 */
var NullValidationHandler = /** @class */ (function () {
    function NullValidationHandler() {
    }
    NullValidationHandler.prototype.validateSignature = function (validationParams) {
        return Promise.resolve(null);
    };
    NullValidationHandler.prototype.validateAtHash = function (validationParams) {
        return Promise.resolve(true);
    };
    return NullValidationHandler;
}());
export { NullValidationHandler };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnVsbC12YWxpZGF0aW9uLWhhbmRsZXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9hbmd1bGFyLW9hdXRoMi1vaWRjLyIsInNvdXJjZXMiOlsidG9rZW4tdmFsaWRhdGlvbi9udWxsLXZhbGlkYXRpb24taGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTs7O0dBR0c7QUFDSDtJQUFBO0lBT0EsQ0FBQztJQU5DLGlEQUFpQixHQUFqQixVQUFrQixnQkFBa0M7UUFDbEQsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFDRCw4Q0FBYyxHQUFkLFVBQWUsZ0JBQWtDO1FBQy9DLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBQ0gsNEJBQUM7QUFBRCxDQUFDLEFBUEQsSUFPQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFZhbGlkYXRpb25IYW5kbGVyLCBWYWxpZGF0aW9uUGFyYW1zIH0gZnJvbSAnLi92YWxpZGF0aW9uLWhhbmRsZXInO1xyXG5cclxuLyoqXHJcbiAqIEEgdmFsaWRhdGlvbiBoYW5kbGVyIHRoYXQgaXNuJ3QgdmFsaWRhdGluZyBub3RoaW5nLlxyXG4gKiBDYW4gYmUgdXNlZCB0byBza2lwIHZhbGlkYXRpb24gKGF0IHlvdXIgb3duIHJpc2spLlxyXG4gKi9cclxuZXhwb3J0IGNsYXNzIE51bGxWYWxpZGF0aW9uSGFuZGxlciBpbXBsZW1lbnRzIFZhbGlkYXRpb25IYW5kbGVyIHtcclxuICB2YWxpZGF0ZVNpZ25hdHVyZSh2YWxpZGF0aW9uUGFyYW1zOiBWYWxpZGF0aW9uUGFyYW1zKTogUHJvbWlzZTxhbnk+IHtcclxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUobnVsbCk7XHJcbiAgfVxyXG4gIHZhbGlkYXRlQXRIYXNoKHZhbGlkYXRpb25QYXJhbXM6IFZhbGlkYXRpb25QYXJhbXMpOiBQcm9taXNlPGJvb2xlYW4+IHtcclxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodHJ1ZSk7XHJcbiAgfVxyXG59XHJcbiJdfQ==