import { __awaiter, __decorate, __generator, __values } from "tslib";
import { Injectable } from '@angular/core';
/**
 * Abstraction for crypto algorithms
*/
var HashHandler = /** @class */ (function () {
    function HashHandler() {
    }
    return HashHandler;
}());
export { HashHandler };
var DefaultHashHandler = /** @class */ (function () {
    function DefaultHashHandler() {
    }
    DefaultHashHandler.prototype.calcHash = function (valueToHash, algorithm) {
        return __awaiter(this, void 0, void 0, function () {
            var encoder, data, hashArray;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        encoder = new TextEncoder();
                        data = encoder.encode(valueToHash);
                        return [4 /*yield*/, window.crypto.subtle.digest(algorithm, data)];
                    case 1:
                        hashArray = _a.sent();
                        return [2 /*return*/, this.toHashString(hashArray)];
                }
            });
        });
    };
    DefaultHashHandler.prototype.toHashString = function (buffer) {
        var e_1, _a;
        var byteArray = new Uint8Array(buffer);
        var result = '';
        try {
            for (var byteArray_1 = __values(byteArray), byteArray_1_1 = byteArray_1.next(); !byteArray_1_1.done; byteArray_1_1 = byteArray_1.next()) {
                var e = byteArray_1_1.value;
                result += String.fromCharCode(e);
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (byteArray_1_1 && !byteArray_1_1.done && (_a = byteArray_1.return)) _a.call(byteArray_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return result;
    };
    DefaultHashHandler = __decorate([
        Injectable()
    ], DefaultHashHandler);
    return DefaultHashHandler;
}());
export { DefaultHashHandler };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFzaC1oYW5kbGVyLmpzIiwic291cmNlUm9vdCI6Im5nOi8vYW5ndWxhci1vYXV0aDItb2lkYy8iLCJzb3VyY2VzIjpbInRva2VuLXZhbGlkYXRpb24vaGFzaC1oYW5kbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDOztFQUVFO0FBQ0Y7SUFBQTtJQUVBLENBQUM7SUFBRCxrQkFBQztBQUFELENBQUMsQUFGRCxJQUVDOztBQUdEO0lBQUE7SUF1Q0EsQ0FBQztJQXJDUyxxQ0FBUSxHQUFkLFVBQWUsV0FBbUIsRUFBRSxTQUFpQjs7Ozs7O3dCQUMzQyxPQUFPLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQzt3QkFDNUIsSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7d0JBQ3ZCLHFCQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUE7O3dCQUE5RCxTQUFTLEdBQUcsU0FBa0Q7d0JBQ3BFLHNCQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEVBQUM7Ozs7S0FDdkM7SUFFRCx5Q0FBWSxHQUFaLFVBQWEsTUFBbUI7O1FBQzlCLElBQU0sU0FBUyxHQUFHLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3pDLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzs7WUFDaEIsS0FBYyxJQUFBLGNBQUEsU0FBQSxTQUFTLENBQUEsb0NBQUEsMkRBQUU7Z0JBQXBCLElBQUksQ0FBQyxzQkFBQTtnQkFDUixNQUFNLElBQUksTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNsQzs7Ozs7Ozs7O1FBQ0QsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztJQWhCUSxrQkFBa0I7UUFEOUIsVUFBVSxFQUFFO09BQ0Esa0JBQWtCLENBdUM5QjtJQUFELHlCQUFDO0NBQUEsQUF2Q0QsSUF1Q0M7U0F2Q1ksa0JBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuLyoqXHJcbiAqIEFic3RyYWN0aW9uIGZvciBjcnlwdG8gYWxnb3JpdGhtc1xyXG4qL1xyXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgSGFzaEhhbmRsZXIge1xyXG4gICAgYWJzdHJhY3QgY2FsY0hhc2godmFsdWVUb0hhc2g6IHN0cmluZywgYWxnb3JpdGhtOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz47XHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIERlZmF1bHRIYXNoSGFuZGxlciBpbXBsZW1lbnRzIEhhc2hIYW5kbGVyIHtcclxuXHJcbiAgICBhc3luYyBjYWxjSGFzaCh2YWx1ZVRvSGFzaDogc3RyaW5nLCBhbGdvcml0aG06IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgICAgICAgY29uc3QgZW5jb2RlciA9IG5ldyBUZXh0RW5jb2RlcigpO1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBlbmNvZGVyLmVuY29kZSh2YWx1ZVRvSGFzaCk7XHJcbiAgICAgICAgY29uc3QgaGFzaEFycmF5ID0gYXdhaXQgd2luZG93LmNyeXB0by5zdWJ0bGUuZGlnZXN0KGFsZ29yaXRobSwgZGF0YSk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMudG9IYXNoU3RyaW5nKGhhc2hBcnJheSk7XHJcbiAgICB9XHJcblxyXG4gICAgdG9IYXNoU3RyaW5nKGJ1ZmZlcjogQXJyYXlCdWZmZXIpIHtcclxuICAgICAgY29uc3QgYnl0ZUFycmF5ID0gbmV3IFVpbnQ4QXJyYXkoYnVmZmVyKTtcclxuICAgICAgbGV0IHJlc3VsdCA9ICcnO1xyXG4gICAgICBmb3IgKGxldCBlIG9mIGJ5dGVBcnJheSkge1xyXG4gICAgICAgIHJlc3VsdCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGUpO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gaGV4U3RyaW5nKGJ1ZmZlcikge1xyXG4gICAgLy8gICAgIGNvbnN0IGJ5dGVBcnJheSA9IG5ldyBVaW50OEFycmF5KGJ1ZmZlcik7XHJcbiAgICAvLyAgICAgY29uc3QgaGV4Q29kZXMgPSBbLi4uYnl0ZUFycmF5XS5tYXAodmFsdWUgPT4ge1xyXG4gICAgLy8gICAgICAgY29uc3QgaGV4Q29kZSA9IHZhbHVlLnRvU3RyaW5nKDE2KTtcclxuICAgIC8vICAgICAgIGNvbnN0IHBhZGRlZEhleENvZGUgPSBoZXhDb2RlLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICAvLyAgICAgICByZXR1cm4gcGFkZGVkSGV4Q29kZTtcclxuICAgIC8vICAgICB9KTtcclxuICAgICAgXHJcbiAgICAvLyAgICAgcmV0dXJuIGhleENvZGVzLmpvaW4oJycpO1xyXG4gICAgLy8gICB9XHJcbiAgICBcclxuICAgICAgLy8gdG9IYXNoU3RyaW5nKGhleFN0cmluZzogc3RyaW5nKSB7XHJcbiAgICAgIC8vICAgbGV0IHJlc3VsdCA9ICcnO1xyXG4gICAgICAvLyAgIGZvciAobGV0IGkgPSAwOyBpIDwgaGV4U3RyaW5nLmxlbmd0aDsgaSArPSAyKSB7XHJcbiAgICAgIC8vICAgICBsZXQgaGV4RGlnaXQgPSBoZXhTdHJpbmcuY2hhckF0KGkpICsgaGV4U3RyaW5nLmNoYXJBdChpICsgMSk7XHJcbiAgICAgIC8vICAgICBsZXQgbnVtID0gcGFyc2VJbnQoaGV4RGlnaXQsIDE2KTtcclxuICAgICAgLy8gICAgIHJlc3VsdCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKG51bSk7XHJcbiAgICAgIC8vICAgfVxyXG4gICAgICAvLyAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgIC8vIH1cclxuXHJcbn0iXX0=